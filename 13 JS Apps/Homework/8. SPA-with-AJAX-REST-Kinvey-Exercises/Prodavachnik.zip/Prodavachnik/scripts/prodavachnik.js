function startApp() {
	showHideMenuLinks();
	showHomeView();
	attachAllEvents();
}