﻿namespace P03_SalesDatabase.Data
{
    public class Configuration
    {
        public const string ConnectionString = "Server=.;Database=SalesDb;Integrated Security=True";
    }
}